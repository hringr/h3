﻿using NewsApplication.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsApplication.Models
{
    public class NewsRepository
    {
        NewsContext m_db = new NewsContext();

        public IEnumerable<NewsItem> GetAllNews()
        {
            var result = (from n in m_db.News
                          orderby n.DateCreated descending
                          select n).Take(10);
            return result;
        }

        public NewsItem GetNewsById(int id)
        {
            var result = (from n in m_db.News
                          where n.Id == id
                          select n).SingleOrDefault();
            return result;
        }

        public void AddNews(NewsItem n)
        {
            m_db.News.Add(n);
            m_db.SaveChanges();
        }

        public void UpdateNews(NewsItem n)
        {
            NewsItem t = GetNewsById(n.Id);
            if (t != null)
            {
                t.Title = n.Title;
                t.Text = n.Text;
                t.Category = n.Category;
                m_db.SaveChanges();
            }
        }

        public void DeleteNews(NewsItem n)
        {
            m_db.News.Remove(n);
            m_db.SaveChanges();
        }
    }
}