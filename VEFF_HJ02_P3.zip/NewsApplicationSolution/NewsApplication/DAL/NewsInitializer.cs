﻿using NewsApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsApplication.DAL
{
    public class NewsInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<NewsContext>
    {
        protected override void Seed(NewsContext context)
        {
            var news = new List<NewsItem>
            {
                new NewsItem
                { 
                    Category="Education", 
                    Title="MSc-nám í klínískri sálfræði hefst í HR í haust",  
                    DateCreated=DateTime.Parse("2005-09-01"), 
                    Text="Námið hefur öðlast viðurkenningu mennta- og menningarmálaráðuneytis og uppfyllir kröfur íslenskra laga um starfsemi sálfræðinga.  Dr. Jón Friðrik Sigurðsson er nýráðinn forstöðumaður námsins."
                },

                new NewsItem
                {
                    Category="Sports", 
                    Title="Þurf­um að vera á lífi eft­ir úti­leik­inn",  
                    DateCreated=DateTime.Parse("2002-09-01"),
                    Text="Aron Kristjáns­son, þjálf­ari danska meist­araliðsins KIF Kol­d­ing Kö­ben­havn, tel­ur að lið sitt eigi ágæta mögu­leika gegn Za­greb frá Króa­tíu en liðin dróg­ust í dag sam­an í 16-liða úr­slit­um Meist­ara­deild­ar Evr­ópu í hand­knatt­leik."
                },

                new NewsItem
                { 
                    Category="News", 
                    Title="Skást að veikj­ast á Íslandi",  
                    DateCreated=DateTime.Parse("2003-09-01"),
                    Text="Hið sænska Aft­on­bla­det birt­ir á heimasíðu sinni kort frá fyr­ir­tæk­inu In­ternati­onal SOS sem sýn­ir þá staði þar sem hættu­leg­ast er að veikj­ast."
                },
            
                new NewsItem
                {
                    Category="Politics", 
                    Title="Vilja sam­ræmd­ar regl­ur um skila­rétt",  
                    DateCreated=DateTime.Parse("2002-09-01"),
                    Text="Fjór­ir þing­menn Fram­sókn­ar­flokks­ins hafa lagt fram þings­álykt­un­ar­til­lögu þess efn­is að iðnaðar- og viðskiptaráðherra verði falið „að skipa starfs­hóp sem taki til end­ur­skoðunar verklags­regl­ur um skila­rétt neyt­enda, gjafa­bréf og inn­eign­arnót­ur og geri til­lög­ur að átaki til að auka notk­un þeirra.“ Fyrsti flutn­ings­maður er Elsa Lára Arn­ar­dótt­ir, þingmaður flokks­ins."
                },
            
                new NewsItem
                {
                    Category="News", 
                    Title="Al­var­legt um­hverf­is­slys",  
                    DateCreated=DateTime.Parse("2002-09-01"),
                    Text="Heil­brigðis­eft­ir­lit Hafn­ar­fjarðar og Kópa­vogs­svæðis hef­ur til­kynnt Um­hverf­is­stofn­un um „al­var­legt um­hverf­is­slys“ vegna spilli­efna sem losuð voru í hluta frá­veitu­kerf­is Kópa­vogs­bæj­ar."
                },

                new NewsItem
                {
                    Category="Sports", 
                    Title="Litla táin fór í tvennt",  
                    DateCreated=DateTime.Parse("2001-09-01"),
                    Text="Hólm­ar Örn Eyj­ólfs­son miss­ir að öll­um lík­ind­um af fyrstu leikj­um Rosen­borg í norsku úr­vals­deild­inni í knatt­spyrnu eft­ir að hann tábrotnaði á æf­ingu liðsins í Þránd­heimi í morg­un."
                },
            
                new NewsItem
                {
                    Category="News", 
                    Title="Eld­gosið að verða hálfs árs",  
                    DateCreated=DateTime.Parse("2003-09-01"),
                    Text="Eld­gosið í Holu­hrauni hef­ur bráðum staðið yfir í hálft ár. Veru­lega hef­ur dregið úr hraun­flæði í Holu­hrauni og hægt á sig­hraða öskju Bárðarbungu. Þá dreg­ur áfram úr jarðskjálfta­virkni Bárðarbungu þó hún telj­ist enn mik­il. Ekki hef­ur mælst skjálfti yfir fimm að stærð frá 8. janú­ar."
                },
            
                new NewsItem
                {
                    Category="Politics", 
                    Title="Grunn­laun dugi fyr­ir nauðsynj­um",  
                    DateCreated=DateTime.Parse("2005-09-01"),
                    Text="Mik­il­vægt er að fólk geti náð lág­marks­laun­um með eðli­legu vinnu­fram­lagi í stað þess að launa­mál þró­ist með þeim hætti að fólk sé á mjög lág­um grunn­laun­um en stór hluti tekna og jafn­vel helm­ing­ur komi vegna viðbót­ar­vinnu. Æskilegt væri enn­frem­ur að grunn­laun fólks nægðu til þess að standa und­ir lífs­nauðsynj­um."
                },
                
                new NewsItem
                {
                    Category="Sports", 
                    Title="Þurf­um að vera á lífi eft­ir úti­leik­inn",  
                    DateCreated=DateTime.Parse("2002-09-01"),
                    Text="Aron Kristjáns­son, þjálf­ari danska meist­araliðsins KIF Kol­d­ing Kö­ben­havn, tel­ur að lið sitt eigi ágæta mögu­leika gegn Za­greb frá Króa­tíu en liðin dróg­ust í dag sam­an í 16-liða úr­slit­um Meist­ara­deild­ar Evr­ópu í hand­knatt­leik."
                },

                new NewsItem
                {
                    Category="News", 
                    Title="Skást að veikj­ast á Íslandi",  
                    DateCreated=DateTime.Parse("2003-09-01"),
                    Text="Hið sænska Aft­on­bla­det birt­ir á heimasíðu sinni kort frá fyr­ir­tæk­inu In­ternati­onal SOS sem sýn­ir þá staði þar sem hættu­leg­ast er að veikj­ast."
                }
            };

            news.ForEach(n => context.News.Add(n));
            context.SaveChanges();
        }
    }
}