﻿using NewsApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NewsApplication.Controllers
{
    //TODO Listi
    /*	0  	Install-Packages EntityFramework +++
     *	1	Model Class +++
     *	2	Context class +++
     *	3	Initializer class +++
     *	4	Reference initializer in web.config +++
     *	5	Add connection string in web.config +++
     *	6	Create scaffolding from model and data context   
     */
    public class HomeController : Controller
    {
        NewsRepository repo = new NewsRepository();

        public ActionResult Index()
        {
            var model = repo.GetAllNews().OrderByDescending(x => x.DateCreated).Take(10);
            return View(model);
        }

        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id.HasValue)
            {
                int realID = id.Value;
                var model = repo.GetNewsById(realID);

                if (model == null)
                {
                    return View("NotFound");
                }

                NewsViewModel t = new NewsViewModel();
                t.ID = model.Id;
                t.Title = model.Title;
                t.Text = model.Text;
                t.DateCreated = model.DateCreated;
                t.Category = model.Category;

                return View(t);
            }
            else 
            {
                return View("NotFound");
            }
        }

        [HttpPost]
        public ActionResult Edit(NewsViewModel n)
        {
            if (ModelState.IsValid)
            {
                NewsItem t = new NewsItem();
                t.Id = n.ID;
                t.Title = n.Title;
                t.Text = n.Text;
                t.DateCreated = n.DateCreated;
                t.Category = n.Category;
                repo.UpdateNews(t);
                return RedirectToAction("Index");
            }
            else
            {
                return View(n);
            }
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View(new NewsViewModel());
        }

        [HttpPost]
        public ActionResult Create(NewsViewModel n)
        {
            if (ModelState.IsValid)
            {
                NewsItem t = new NewsItem();
//                t.AddNews(NewsItem(n))
                return RedirectToAction("Index");
            }
            return View(new NewsViewModel());
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}